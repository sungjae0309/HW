﻿#include <bangtal.h>


SceneID scene1;

ObjectID startButton, endButton, playButton;
ObjectID santa;

int santaX = 0, santaY = 500;

TimerID timer1; 

void startGame() {
	hideObject(startButton);
	hideObject(endButton);

	showObject(playButton);

	setTimer(timer1, 10.f);

	startTimer(timer1);
}

void endGame(bool success) 
{
	if (success) {
		showMessage("선물 배달 성공!!!");
	}
	else {
		showMessage("헉, 선물 배달 실패!!!");
	}

		hideObject(playButton);

		setObjectImage(startButton, "restart.png");

		showObject(startButton);
		showObject(endButton);


		santaX = 0;
		locateObject(santa, scene1, santaX, santaY);

		stopTimer(timer1);
	
}

void mouseCallback(ObjectID object, int x, int y, MouseAction action) 
{
	if (object == endButton) {
		endGame();
	}
	else if (object == startButton) {
		startGame();

	}

	else if (object == playButton) {
		santaX = santaX + 30;
		locateObject(santa, scene1, santaX, santaY);

		if (santaX > 1280) {
			endGame(true);
		}
	}
}
void timerCallback(TimerID timer) 
{
	if (timer == timer1) {
		endGame(false);
		
	}
}


ObjectID createObject(const char* image, SceneID scene, int x, int y, bool shown)
{
	ObjectID object = createObject(image);
	locateObject(object, scene, x, y);
	if (shown) {
		showObject(object);
	}
	return object;
}
int main()
{
	setGameOption(GameOption::GAME_OPTION_ROOM_TITLE, false);
	setGameOption(GameOption::GAME_OPTION_INVENTORY_BUTTON, false);
	setGameOption(GameOption::GAME_OPTION_MESSAGE_BOX_BUTTON, false);

	setMouseCallback(mouseCallback);
	setTimerCallback(timerCallback);

	scene1 = createScene("SantaRace", "background.png");
	
	
	startButton = createObject("start.png", scene1, 590, 70, true);
	endButton = createObject("end.png", scene1, 590, 20, true);
	santa = createObject("santa.png", scene1, santaX, santaY, true);
	playButton = createObject("play.png", scene1, 610, 30, false);

	timer1 = createTimer(10.f);

	showTimer(timer1);




	startGame(scene1);
}

